#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LibraryGenie - Plugin Entry Point
Handles plugin URL routing using new modular architecture
"""

import sys
from typing import TYPE_CHECKING

import xbmcaddon
import xbmcgui
import xbmc
import xbmcplugin
import xbmcvfs

# Import shared utilities
from lib.utils.kodi_log import log, log_info, log_error, log_warning

# First run marker file path (lightweight check - no DB access)
FIRST_RUN_MARKER = 'special://userdata/addon_data/plugin.video.librarygenie/.first_run_complete'

# Heavy imports now lazy loaded in their respective functions for better startup performance
# Type annotations only - no runtime imports
if TYPE_CHECKING:
    from lib.ui.router import Router
    from lib.ui.plugin_context import PluginContext

# PluginContext import moved to function scope to avoid heavy startup imports

# Using direct Kodi logging via lib.utils.kodi_log

# Cached config instance to avoid repeated initialization
_cached_config = None

def _get_cached_config():
    """Get cached config instance to avoid repeated get_config() calls"""
    global _cached_config
    if _cached_config is None:
        from lib.config.config_manager import get_config
        _cached_config = get_config()
    return _cached_config

def _get_factory():
    """Get handler factory instance with lazy import for maximum performance"""
    from lib.ui.handler_factory import get_handler_factory
    return get_handler_factory()


# ============================================================================
# ULTRA-FAST CACHE-ONLY SERVING FUNCTIONS
# These functions bypass the entire plugin architecture for maximum speed
# ============================================================================

def _parse_action_minimal():
    """Parse action from sys.argv without any imports"""
    try:
        if len(sys.argv) > 2:
            query_string = sys.argv[2][1:] if len(sys.argv[2]) > 1 else ""
            from urllib.parse import parse_qsl
            params = dict(parse_qsl(query_string))
            return params.get('action', ''), params
        return '', {}
    except Exception:
        return '', {}

def _get_cache_dir_direct():
    """Get cache directory path with minimal imports"""
    try:
        import xbmcvfs
        import os
        profile_dir = xbmcvfs.translatePath('special://profile/')
        return os.path.join(profile_dir, 'addon_data', 'plugin.video.librarygenie', 'cache', 'folders')
    except Exception:
        return None

def _get_cache_file_direct(folder_id):
    """Get cache file path directly without FolderCache class"""
    try:
        import os
        import hashlib
        import glob
        
        cache_dir = _get_cache_dir_direct()
        if not cache_dir or not os.path.exists(cache_dir):
            return None
            
        # Handle root directory
        if folder_id in [None, '', 'root']:
            # Look for root cache files (both anon and user-scoped)
            patterns = [
                os.path.join(cache_dir, "folder_root_*_anon_v*.json"),
                os.path.join(cache_dir, "folder_root_*_v*.json")
            ]
            all_files = []
            for pattern in patterns:
                all_files.extend(glob.glob(pattern))
            
            if not all_files:
                return None
                
            # Select newest file by modification time
            return max(all_files, key=lambda f: os.path.getmtime(f))
        else:
            # Handle specific folder ID
            safe_folder_id = "".join(c for c in str(folder_id) if c.isalnum() or c in '-_').strip()
            folder_hash = hashlib.sha1(str(folder_id).encode('utf-8')).hexdigest()[:8]
            patterns = [
                os.path.join(cache_dir, f"folder_{safe_folder_id}_{folder_hash}_anon_v*.json"),
                os.path.join(cache_dir, f"folder_{safe_folder_id}_{folder_hash}_v*.json")
            ]
            all_files = []
            for pattern in patterns:
                all_files.extend(glob.glob(pattern))
                
            if not all_files:
                return None
                
            # Select newest file by modification time
            return max(all_files, key=lambda f: os.path.getmtime(f))
    except Exception:
        return None

def _is_cache_fresh_direct(cache_file, ttl_hours=12):
    """Check if cache file is fresh without loading settings"""
    try:
        import os
        from datetime import datetime, timedelta
        
        if not cache_file or not os.path.exists(cache_file):
            return False
            
        file_time = datetime.fromtimestamp(os.path.getmtime(cache_file))
        cutoff_time = datetime.now() - timedelta(hours=ttl_hours)
        return file_time > cutoff_time
    except Exception:
        return False

def _load_cache_direct(cache_file):
    """Load cache file directly without FolderCache class"""
    try:
        import json
        with open(cache_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None

def _can_serve_from_cache_only(action, params=None):
    """Check if request can be served entirely from cache"""
    # Root actions can use V4 cache with processed items
    if action in ['', 'main_menu', 'show_lists_menu']:
        cache_file = _get_cache_file_direct(None)  # Root folder
        return cache_file and _is_cache_fresh_direct(cache_file)
    
    # Handle folder navigation cache serving
    if action == 'show_folder':
        folder_id = params.get('folder_id') if params else None
        # Prevent root bypass - always use full pipeline for root folder
        if folder_id in [None, '', 'root']:
            return False
        if folder_id:
            cache_file = _get_cache_file_direct(folder_id)
            return cache_file and _is_cache_fresh_direct(cache_file)
    
    return False

def _serve_from_cache_ultra_fast(action, params=None):
    """Serve request from cache without PluginContext, Router, or managers"""
    try:
        log("=== ULTRA-FAST CACHE SERVING ===")
        
        # Get addon handle
        addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        if addon_handle < 0:
            return False
            
        # Determine folder ID
        folder_id = None
        if action == 'show_folder':
            folder_id = params.get('folder_id') if params else None
            
        # Load cached data
        cache_file = _get_cache_file_direct(folder_id)
        if not cache_file:
            log("No cache file found")
            return False
            
        cached_data = _load_cache_direct(cache_file)
        if not cached_data:
            log("Failed to load cache data")
            return False
            
        log(f"Serving from cache: {cache_file}")
        
        # Render cached items directly
        _render_cached_items_direct(cached_data, addon_handle)
        return True
        
    except Exception as e:
        log_error(f"Ultra-fast cache serving failed: {e}")
        return False

def _get_simple_resource_art(item_type):
    """
    Get resource artwork for folders/lists without requiring full renderer.
    Simple implementation for ultra-fast rendering.
    
    Args:
        item_type: 'folder' or 'list'
        
    Returns:
        Dict of art paths or empty dict
    """
    try:
        import os
        addon = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        resources_dir = os.path.join(addon_path, 'resources')
        
        # Map type to resource files
        if item_type == 'folder':
            icon_file = 'list_folder_icon.png'
            thumb_file = 'list_folder.jpg'
        elif item_type == 'list':
            icon_file = 'list_playlist_icon.png'
            thumb_file = 'list_playlist.jpg'
        else:
            return {}
        
        icon_path = os.path.join(resources_dir, icon_file)
        thumb_path = os.path.join(resources_dir, thumb_file)
        
        art = {}
        if os.path.exists(icon_path):
            art['icon'] = icon_path
        if os.path.exists(thumb_path):
            art['thumb'] = thumb_path
            art['poster'] = thumb_path
        
        return art
    except Exception:
        return {}

def _render_cached_items_direct(cached_data, addon_handle):
    """Render cached processed items directly to Kodi without full plugin infrastructure"""
    try:
        # Use pre-processed menu items from V4 cache
        processed_items = cached_data.get('processed_items', [])
        total_items = 0
        
        for item_data in processed_items:
            listitem = xbmcgui.ListItem(label=item_data.get('label', 'Unknown Item'))
            
            # Set description/plot if available
            if item_data.get('description'):
                listitem.setInfo('video', {'plot': item_data['description']})
            
            # Apply comprehensive artwork from art_data if available
            art_applied = False
            art_data = item_data.get('art_data')
            if art_data:
                try:
                    import json
                    # Parse if it's a JSON string
                    if isinstance(art_data, str):
                        try:
                            art_data = json.loads(art_data)
                        except (json.JSONDecodeError, ValueError) as e:
                            log_error(f"Failed to parse art_data JSON: {e}")
                            art_data = None
                    
                    # Apply the art dictionary if valid
                    if art_data and isinstance(art_data, dict):
                        listitem.setArt(art_data)
                        art_applied = True
                except Exception as e:
                    log_error(f"Failed to apply art_data: {e}")
            
            # Fallback: compute resource art based on item type
            if not art_applied:
                # Determine item type from URL
                url = item_data.get('url', '')
                if 'action=show_folder' in url:
                    resource_art = _get_simple_resource_art('folder')
                elif 'action=show_list' in url:
                    resource_art = _get_simple_resource_art('list')
                else:
                    resource_art = {}
                
                # Apply resource art if found
                if resource_art:
                    listitem.setArt(resource_art)
                    art_applied = True
                # Use icon field if available
                elif item_data.get('icon'):
                    listitem.setArt({'icon': item_data['icon'], 'thumb': item_data['icon']})
                    art_applied = True
            
            # Ultimate fallback if still no art
            if not art_applied:
                default_icon = 'DefaultFolder.png' if item_data.get('is_folder') else 'DefaultVideo.png'
                listitem.setArt({'icon': default_icon, 'thumb': default_icon})
            
            # Add context menu if available
            if item_data.get('context_menu'):
                listitem.addContextMenuItems(item_data['context_menu'])
            
            # Set properties
            listitem.setProperty('IsPlayable', 'false')
            
            xbmcplugin.addDirectoryItem(
                handle=addon_handle,
                url=item_data.get('url', ''),
                listitem=listitem,
                isFolder=item_data.get('is_folder', True)
            )
            total_items += 1
        
        # Set content type and finish
        content_type = cached_data.get('content_type', 'files')
        xbmcplugin.setContent(addon_handle, content_type)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=False)
        
        log(f"Ultra-fast rendering complete: {total_items} processed items")
        
    except Exception as e:
        log_error(f"Direct rendering failed: {e}")
        import traceback
        log_error(f"Direct rendering traceback: {traceback.format_exc()}")
        # Fallback - end directory safely
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)


def handle_authorize():
    """Handle device authorization"""
    from lib.auth.auth_helper import get_auth_helper
    auth_helper = get_auth_helper()
    auth_helper.start_device_authorization()


def handle_signout():
    """Handle user sign out"""
    from lib.auth.state import clear_tokens

    addon = xbmcaddon.Addon()

    from lib.ui.localization import L

    # Confirm sign out
    dialog = xbmcgui.Dialog()
    if dialog.yesno(
        heading=L(30136),  # "LibraryGenie"
        message=f"{L(30163)}\n{L(30164)}",  # "Sign out" + "Are you sure you want to sign out?"
        nolabel=L(30215),  # "Cancel"
        yeslabel=L(30163)  # "Sign out"
    ):
        if clear_tokens():
            xbmcgui.Dialog().notification(
                addon.getLocalizedString(30136),  # "LibraryGenie"
                addon.getLocalizedString(30165),  # "Signed out successfully"
                xbmcgui.NOTIFICATION_INFO
            )
        else:
            xbmcgui.Dialog().notification(
                addon.getLocalizedString(30136),  # "LibraryGenie"
                addon.getLocalizedString(30166),  # "Sign out failed"
                xbmcgui.NOTIFICATION_ERROR
            )





def handle_on_select(params: dict, addon_handle: int):
    """Handle library item selection - play media directly"""
    try:
        import re

        log("=== ON_SELECT HANDLER CALLED ===")
        log(f"Handling on_select with params: {params}")
        log(f"Addon handle: {addon_handle}")

        dbtype = params.get("dbtype", "movie")
        dbid = int(params.get("dbid", "0"))
        tvshowid = params.get("tvshowid")
        season = params.get("season")
        tvshowid = int(tvshowid) if tvshowid and str(tvshowid).isdigit() else None
        season = int(season) if season and str(season).isdigit() else None

        # Build videodb:// path for Kodi library items
        if dbtype == "movie":
            vdb = f'videodb://movies/titles/{dbid}'
        elif dbtype == "episode":
            if isinstance(tvshowid, int) and isinstance(season, int):
                vdb = f'videodb://tvshows/titles/{tvshowid}/{season}/{dbid}'
            else:
                vdb = f'videodb://episodes/{dbid}'
        else:
            vdb = ""
        log(f"on_select: dbtype={dbtype}, dbid={dbid}, videodb_path={vdb}")

        # Always play the media directly
        log_info(f"Playing media: {vdb}")
        xbmc.executebuiltin(f'PlayMedia("{vdb}")')

        # Don’t render a directory for this action
        try:
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        except Exception:
            pass

    except Exception as e:
        log_error(f"Error in handle_on_select: {e}")
        import traceback
        log_error(f"on_select error traceback: {traceback.format_exc()}")
        try:
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        except Exception:
            pass


# Legacy handle_lists and handle_kodi_favorites functions removed
# Functionality moved to ListsHandler class


# Legacy favorites handlers removed - functionality moved to FavoritesHandler class


def handle_settings():
    """Handle settings menu"""
    log_info("Opening addon settings")
    xbmcaddon.Addon().openSettings()



def _handle_manual_backup(context: 'PluginContext'):
    """Handle manual backup from settings"""
    try:
        log_info("Running manual backup from settings")

        from lib.import_export import get_timestamp_backup_manager
        backup_manager = get_timestamp_backup_manager()

        result = backup_manager.run_automatic_backup()

        if result["success"]:
            size_mb = round(result.get('file_size', 0) / 1024 / 1024, 2) if result.get('file_size') else 0
            message = (
                f"Manual backup completed successfully!\n\n"
                f"Filename: {result.get('filename', 'Unknown')}\n"
                f"Size: {size_mb} MB\n"
                f"Items: {result.get('total_items', 0)}\n"
                f"Location: {result.get('storage_location', 'Unknown')}"
            )
            xbmcgui.Dialog().ok("Manual Backup", message)
        else:
            error_msg = result.get("error", "Unknown error")
            xbmcgui.Dialog().ok("Manual Backup Failed", f"Backup failed:\n{error_msg}")

    except Exception as e:
        log_error(f"Error in manual backup handler: {e}")
        xbmcgui.Dialog().ok("Manual Backup Error", f"Backup error: {str(e)}")

    # Don't render directory for settings actions
    try:
        if context.addon_handle >= 0:
            xbmcplugin.endOfDirectory(context.addon_handle, succeeded=False)
    except Exception:
        pass


def _handle_restore_backup(context: 'PluginContext'):
    """Handle restore backup from settings - delegated to tools handler"""
    try:
        from lib.ui.tools_handler import ToolsHandler
        tools_handler = ToolsHandler()

        # Call the restore backup method from tools handler
        response = tools_handler.restore_backup_from_settings()

        # Handle the response appropriately
        from lib.ui.response_types import DialogResponse
        from lib.ui.response_handler import get_response_handler

        if isinstance(response, DialogResponse):
            response_handler = get_response_handler()
            response_handler.handle_dialog_response(response, context)

    except Exception as e:
        log_error(f"Error in restore backup handler: {e}")
        xbmcgui.Dialog().ok("Restore Backup Error", f"An error occurred: {str(e)}")

    # Don't render directory for settings actions
    try:
        if context.addon_handle >= 0:
            xbmcplugin.endOfDirectory(context.addon_handle, succeeded=False)
    except Exception:
        pass


def handle_shortlist_import():
    """Handle ShortList import action from settings"""
    import xbmcgui

    log_info("=== SHORTLIST IMPORT HANDLER CALLED ===")
    
    progress = None  # Initialize to avoid LSP warning about possibly unbound variable

    try:
        log_info("Starting ShortList import process")

        # Show confirmation dialog
        dialog = xbmcgui.Dialog()

        from lib.ui.localization import L

        log_info("Showing confirmation dialog")
        if not dialog.yesno(
            L(30071),  # "Import from ShortList addon"
            L(30349) + "\n" + L(32326),  # Combined message
            nolabel=L(30215),  # "Cancel"
            yeslabel=L(32327)  # "Continue"
        ):
            log_info("User cancelled ShortList import")
            return

        log_info("User confirmed import, proceeding...")

        # Show progress dialog
        progress = xbmcgui.DialogProgress()
        progress.create("ShortList Import", "Checking ShortList addon...")
        progress.update(10)

        log_info("Attempting to get ShortList importer instance...")
        try:
            from lib.import_export.shortlist_importer import get_shortlist_importer
            log_info("Successfully imported get_shortlist_importer function")

            importer = get_shortlist_importer()
            log_info(f"Successfully got importer instance: {type(importer)}")

        except Exception as import_e:
            log_error(f"Error importing or getting ShortList importer: {import_e}")
            import traceback
            log_error(f"Import error traceback: {traceback.format_exc()}")
            progress.close()
            dialog.notification(
                "LibraryGenie",
                "Failed to load ShortList importer",
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
            return

        # Check if ShortList is available
        log_info("Checking if ShortList addon is installed...")
        try:
            is_installed = importer.is_shortlist_installed()
            log_info(f"ShortList installed check result: {is_installed}")

            if not is_installed:
                progress.close()
                dialog.notification(
                    "LibraryGenie",
                    "ShortList addon not found or not enabled",
                    xbmcgui.NOTIFICATION_WARNING,
                    5000
                )
                return
        except Exception as check_e:
            log_error(f"Error checking ShortList installation: {check_e}")
            import traceback
            log_error(f"Check error traceback: {traceback.format_exc()}")
            progress.close()
            dialog.notification(
                "LibraryGenie",
                "Error checking ShortList addon",
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
            return

        progress.update(30, "Scanning ShortList data...")

        log_info("About to call importer.import_shortlist_items()")
        log_info(f"Importer type: {type(importer)}")
        log_info(f"Importer instance: {importer}")

        # Check if the method exists
        if hasattr(importer, 'import_shortlist_items'):
            log_info(f"import_shortlist_items method exists: {importer.import_shortlist_items}")
            log_info(f"import_shortlist_items callable: {callable(importer.import_shortlist_items)}")
        else:
            log_error("import_shortlist_items method does not exist on importer!")
            progress.close()
            dialog.notification(
                "LibraryGenie",
                "ShortList importer missing method",
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
            return

        # Perform the import
        log_info("=== CALLING IMPORT METHOD ===")
        try:
            log_info("Calling import_shortlist_items method...")
            result = importer.import_shortlist_items()
            log_info("=== IMPORT METHOD COMPLETED ===")
            log_info(f"Import result type: {type(result)}")
            log_info(f"Import result: {result}")
        except TypeError as te:
            log_error("=== IMPORT METHOD TYPEERROR ===")
            log_error(f"TypeError calling import_shortlist_items: {te}")
            import traceback
            log_error(f"TypeError traceback: {traceback.format_exc()}")

            # Try to get more info about the method signature
            import inspect
            try:
                sig = inspect.signature(importer.import_shortlist_items)
                log_error(f"Method signature: {sig}")
            except Exception as sig_e:
                log_error(f"Could not get method signature: {sig_e}")

            raise
        except Exception as e:
            log_error("=== IMPORT METHOD ERROR ===")
            log_error(f"Error calling import_shortlist_items: {e}")
            import traceback
            log_error(f"Import method traceback: {traceback.format_exc()}")
            raise

        progress.update(100, "Import complete!")
        progress.close()

        log_info("Processing import results...")
        if result.get("success"):
            message = (
                f"Import completed!\n"
                f"Processed: {result.get('total_items', 0)} items\n"
                f"Added to list: {result.get('items_added', 0)} movies\n"
                f"Unmapped: {result.get('items_unmapped', 0)} items"
            )
            dialog.ok("ShortList Import", message)
            log_info("ShortList import completed successfully")
        else:
            error_msg = result.get("error", "Unknown error occurred")
            dialog.ok("ShortList Import", f"Import failed: {error_msg}")
            log_error(f"ShortList import failed: {error_msg}")

    except Exception as e:
        log_error("=== SHORTLIST HANDLER EXCEPTION ===")
        log_error(f"ShortList import handler error: {e}")
        import traceback
        log_error(f"Handler exception traceback: {traceback.format_exc()}")

        try:
            if progress is not None:
                progress.close()
        except:
            pass

        xbmcgui.Dialog().notification(
            "LibraryGenie",
            "Import failed with error",
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )


def handle_noop():
    """No-op handler that safely ends the directory without args mismatches"""
    try:
        addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        if addon_handle >= 0:
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    except Exception:
        pass


def _ensure_startup_initialization(context: 'PluginContext'):
    """Optimized startup initialization - leverage service initialization"""
    try:
        log("=== OPTIMIZED STARTUP INITIALIZATION ===")
        
        if _is_service_database_ready():
            log("Service database ready - using fast startup path")
            _fast_startup_check(context)
        else:
            log("Service not ready - using standard startup path")
            _standard_startup_initialization(context)
            
    except Exception as e:
        log_error(f"Startup initialization error: {e}")
        import traceback
        log_error(f"Initialization error traceback: {traceback.format_exc()}")
        # Don't fail the plugin startup for initialization issues
        pass

def _is_service_database_ready():
    """Check if service has database optimization ready"""
    try:
        import xbmcgui
        window = xbmcgui.Window(10000)
        return bool(window.getProperty('librarygenie.db.optimized'))
    except:
        return False

def _fast_startup_check(context):
    """Minimal startup checks when service has done heavy lifting"""
    # Only check settings that don't require database operations
    config = _get_cached_config()
    
    favorites_enabled = config.get_bool('favorites_integration_enabled', False)
    log(f"Fast startup: favorites_enabled={favorites_enabled}")
    
    # Skip database verification - trust service initialization

def _standard_startup_initialization(context: 'PluginContext'):
    """Standard startup when service optimization not available"""
    log("=== STANDARD STARTUP INITIALIZATION ===")
    
    # Check if favorites integration is enabled
    config = _get_cached_config()
    favorites_enabled = config.get_bool('favorites_integration_enabled', False)
    log(f"Favorites integration enabled: {favorites_enabled}")
    
    if favorites_enabled:
        log("Favorites integration is enabled - ensuring Kodi Favorites list exists")
        
        # Use context query manager for consistency
        query_manager = context.query_manager
        
        if query_manager and query_manager.initialize():
            with query_manager.connection_manager.transaction() as conn:
                # Check if Kodi Favorites list exists
                kodi_list = conn.execute("""
                    SELECT id FROM lists WHERE name = 'Kodi Favorites'
                """).fetchone()
                
                if not kodi_list:
                    # Create the Kodi Favorites list since it doesn't exist
                    log_info("STARTUP: Creating 'Kodi Favorites' list - setting is enabled but list doesn't exist")
                    
                    try:
                        from lib.config.favorites_helper import on_favorites_integration_enabled
                        on_favorites_integration_enabled()
                        log_info("STARTUP: Successfully ensured 'Kodi Favorites' list exists")
                    except Exception as e:
                        log_error(f"STARTUP: Failed to create 'Kodi Favorites' list: {e}")
                else:
                    log(f"STARTUP: 'Kodi Favorites' list already exists with ID {kodi_list['id']}")
        else:
            log_warning("STARTUP: Could not initialize query manager for startup check")
    else:
        log("STARTUP: Favorites integration is disabled - skipping Kodi Favorites list check")
        
    log("=== STANDARD STARTUP INITIALIZATION COMPLETE ===")


def main():
    """Main plugin entry point with ultra-fast cache optimization"""
    
    log("=== PLUGIN INVOCATION (CACHE-OPTIMIZED) ===")
    log(f"Full sys.argv: {sys.argv}")
    
    try:
        # STEP 0: Ultra-lightweight first run check (file existence only - no DB)
        if _is_first_run():
            log_info("First run detected - loading setup flow")
            # Must load full architecture for first run setup
            from lib.ui.plugin_context import PluginContext
            context = PluginContext()
            _ensure_startup_initialization(context)
            _check_and_handle_fresh_install(context)
            # After setup, continue to main menu
            from lib.ui.router import Router
            router = Router()
            _register_all_handlers(router)
            if not router.dispatch(context):
                factory = _get_factory()
                main_menu_handler = factory.get_main_menu_handler()
                main_menu_handler.show_main_menu(context)
            return
        
        # STEP 1: Parse action with minimal imports (ultra-fast)
        action, params = _parse_action_minimal()
        log(f"Parsed action: '{action}' with minimal imports")
        
        # STEP 2: Early cache check - try to serve from cache without any heavy imports
        if _can_serve_from_cache_only(action, params):
            log("Cache hit - serving ultra-fast without plugin architecture")
            if _serve_from_cache_ultra_fast(action, params):
                log("Ultra-fast cache serving successful")
                return  # SUCCESS - Exit without heavy imports!
            else:
                log("Ultra-fast cache serving failed - falling back to normal flow")
        else:
            log("Cache miss or uncacheable action - loading full plugin architecture")
        
        # STEP 3: Cache miss or failure - load full plugin architecture
        log("Loading heavy components for full plugin flow")
        from lib.ui.plugin_context import PluginContext
        from lib.ui.router import Router

        context = PluginContext()

        # Log window state for debugging
        _log_window_state(context)

        # STEP 4: Always run initialization for fallback path
        log("Cache miss or failure - running full initialization for safety")
        _ensure_startup_initialization(context)

        router = Router()
        _register_all_handlers(router)

        # Try to dispatch the request
        if not router.dispatch(context):
            # No handler found, show main menu using lazy factory
            factory = _get_factory()
            main_menu_handler = factory.get_main_menu_handler()
            main_menu_handler.show_main_menu(context)
        

    except Exception as e:
        
        log_error(f"Fatal error in plugin main: {e}")
        import traceback
        log_error(f"Main error traceback: {traceback.format_exc()}")

        # Try to show error to user if possible
        try:
            addon = xbmcaddon.Addon()
            xbmcgui.Dialog().notification(
                addon.getLocalizedString(30136),
                addon.getLocalizedString(30147),
                xbmcgui.NOTIFICATION_ERROR
            )
        except Exception:
            pass


def _log_window_state(context: 'PluginContext'):
    """Log window state for debugging"""
    try:
        current_window = xbmc.getInfoLabel("System.CurrentWindow")
        current_control = xbmc.getInfoLabel("System.CurrentControl")
        container_path = xbmc.getInfoLabel("Container.FolderPath")
        container_label = xbmc.getInfoLabel("Container.FolderName")

        log("Window state at plugin entry:")
        log(f"  Current window: {current_window}")
        log(f"  Current control: {current_control}")
        log(f"  Container path: {container_path}")
        log(f"  Container label: {container_label}")

        # Check specific window visibility states
        myvideo_nav_visible = xbmc.getCondVisibility("Window.IsVisible(MyVideoNav.xml)")
        dialog_video_info_visible = xbmc.getCondVisibility("Window.IsVisible(DialogVideoInfo.xml)")
        dialog_video_info_active = xbmc.getCondVisibility("Window.IsActive(DialogVideoInfo.xml)")
        keyboard_visible = xbmc.getCondVisibility("Window.IsVisible(DialogKeyboard.xml)")

        log(f"  MyVideoNav.xml visible: {myvideo_nav_visible}")
        log(f"  DialogVideoInfo.xml visible: {dialog_video_info_visible}")
        log(f"  DialogVideoInfo.xml active: {dialog_video_info_active}")
        log(f"  DialogKeyboard.xml visible: {keyboard_visible}")

    except Exception as e:
        log_warning(f"Failed to log window state at plugin entry: {e}")


def _is_first_run() -> bool:
    """Lightweight file-based first run check - no DB access"""
    return not xbmcvfs.exists(FIRST_RUN_MARKER)

def _mark_first_run_complete():
    """Create marker file to indicate first run is complete"""
    try:
        # Ensure directory exists
        marker_dir = 'special://userdata/addon_data/plugin.video.librarygenie/'
        xbmcvfs.mkdirs(marker_dir)
        
        # Create marker file
        f = xbmcvfs.File(FIRST_RUN_MARKER, 'w')
        f.write('1')
        f.close()
        log_info("First run marker file created")
    except Exception as e:
        log_error(f"Failed to create first run marker: {e}")

def _check_and_handle_fresh_install(context: 'PluginContext') -> bool:
    """Check for fresh install and show setup modal if needed. Returns True if handled."""
    try:
        from lib.library.sync_controller import SyncController
        from lib.ui.localization import L
        
        # Lightweight file check - no DB access
        if not _is_first_run():
            return False
            
        log_info("First run detected - showing setup modal")
        
        sync_controller = SyncController()
        
        # Show welcome dialog first with explanation
        dialog = xbmcgui.Dialog()
        
        # Show welcome/explanation dialog
        dialog.ok(L(30591), L(30592))  # Welcome title and detailed explanation
        
        # Show fresh install setup dialog with enhanced options
        # Create setup options with enhanced descriptions
        options = [
            L(30187),  # Enhanced "Movies and TV Episodes (Recommended)" with description
            L(30188),  # Enhanced "Movies Only" with description  
            L(30189),  # Enhanced "TV Episodes Only" with description
            L(30190)   # Enhanced "Skip Setup (Configure Later)" with description
        ]
        
        # Use compatible dialog.select parameters with proper type casting
        selected = dialog.select(L(30186), list(options))  # "LibraryGenie Setup"
        
        # Handle user selection
        if selected == -1:  # User canceled or pressed back
            log_info("Fresh install setup canceled by user")
            return True  # Handled cancellation, continue to main menu
            
        elif selected == 0:  # Both movies and TV episodes
            log_info("User selected: Movies and TV Episodes")
            _show_setup_progress(L(30191))  # "Setting up Movies and TV Episodes sync..."
            sync_controller.complete_first_run_setup(sync_movies=True, sync_tv_episodes=True)
            # Create lightweight marker file
            _mark_first_run_complete()
            _show_setup_complete(L(30194))  # "Setup complete! Both movies and TV episodes will be synced."
            
        elif selected == 1:  # Movies only
            log_info("User selected: Movies Only")
            _show_setup_progress(L(30192))  # "Setting up Movies sync..."
            sync_controller.complete_first_run_setup(sync_movies=True, sync_tv_episodes=False)
            # Create lightweight marker file
            _mark_first_run_complete()
            _show_setup_complete(L(30195))  # "Setup complete! Movies will be synced."
            
        elif selected == 2:  # TV Episodes only
            log_info("User selected: TV Episodes Only")
            _show_setup_progress(L(30193))  # "Setting up TV Episodes sync..."
            sync_controller.complete_first_run_setup(sync_movies=False, sync_tv_episodes=True)
            # Create lightweight marker file
            _mark_first_run_complete()
            _show_setup_complete(L(30196))  # "Setup complete! TV episodes will be synced."
            
        elif selected == 3:  # Skip setup
            log_info("User selected: Skip Setup")
            # Mark first run complete but don't enable any syncing
            sync_controller.complete_first_run_setup(sync_movies=False, sync_tv_episodes=False)
            # Create lightweight marker file
            _mark_first_run_complete()
            xbmcgui.Dialog().notification(
                L(30136),   # "LibraryGenie"
                L(30531),   # "Setup skipped. Configure sync options in Settings."
                xbmcgui.NOTIFICATION_INFO,
                4000
            )
        
        return True  # Handled fresh install, continue to main menu
        
    except Exception as e:
        log_error(f"Error during fresh install setup: {e}")
        # On error, mark first run complete to avoid infinite loops
        try:
            from lib.library.sync_controller import SyncController
            sync_controller = SyncController()
            sync_controller.complete_first_run_setup(sync_movies=True, sync_tv_episodes=False)
            # Force cache reload to prevent showing setup again
            _get_cached_config().invalidate('first_run_completed')
        except:
            pass
        
        from lib.ui.localization import L
        xbmcgui.Dialog().notification(
            L(30136),   # "LibraryGenie"
            L(30198),   # "Setup error - using default settings"
            xbmcgui.NOTIFICATION_WARNING,
            4000
        )
        return True


def _show_setup_progress(message: str):
    """Show setup progress notification"""
    from lib.ui.localization import L
    xbmcgui.Dialog().notification(
        L(30186),   # "LibraryGenie Setup"
        message,
        xbmcgui.NOTIFICATION_INFO,
        1000
    )


def _show_setup_complete(message: str):
    """Show setup completion notification"""
    from lib.ui.localization import L
    xbmcgui.Dialog().notification(
        L(30186),   # "LibraryGenie Setup"
        message,
        xbmcgui.NOTIFICATION_INFO,
        1000
    )




def _handle_manual_library_sync(context: 'PluginContext'):
    """Handle manual library sync triggered from settings"""
    try:
        from lib.library.sync_controller import SyncController
        
        log_info("Manual library sync triggered from settings")
        
        # Show initial notification
        xbmcgui.Dialog().notification(
            "LibraryGenie",
            "Starting library sync...",
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
        
        # Perform sync
        sync_controller = SyncController()
        success, message = sync_controller.perform_manual_sync()
        
        # Show result notification
        if success:
            xbmcgui.Dialog().notification(
                "LibraryGenie",
                message,
                xbmcgui.NOTIFICATION_INFO,
                6000
            )
            log_info(f"Manual library sync completed successfully: {message}")
        else:
            xbmcgui.Dialog().notification(
                "LibraryGenie",
                f"Sync failed: {message}",
                xbmcgui.NOTIFICATION_ERROR,
                8000
            )
            log_warning(f"Manual library sync failed: {message}")
            
    except Exception as e:
        error_msg = f"Manual sync error: {str(e)}"
        log_error(error_msg)
        xbmcgui.Dialog().notification(
            "LibraryGenie",
            error_msg,
            xbmcgui.NOTIFICATION_ERROR,
            6000
        )


def _register_all_handlers(router: 'Router'):
    """Register all action handlers with the router using per-call lazy factory"""
    # Handler factory now loaded per-call for maximum lazy loading via module-level _get_factory()

    # Register handlers with true lazy instantiation - factory only created when route is invoked
    router.register_handler('search', lambda ctx: _get_factory().get_search_handler().prompt_and_search(ctx))
    router.register_handler('ai_search_prompt', lambda ctx: _get_factory().get_search_handler().ai_search_prompt(ctx))
    router.register_handler('lists', lambda ctx: _get_factory().get_lists_handler().show_lists_menu(ctx))
    router.register_handler('kodi_favorites', lambda ctx: _handle_directory_response(ctx, _get_factory().get_favorites_handler().show_favorites_menu(ctx)))

    # Register ListsHandler methods that expect specific parameters
    def _handle_create_list(ctx):
        factory = _get_factory()
        factory.context = ctx
        return _handle_dialog_response(ctx, factory.get_lists_handler().create_list(ctx))
    
    def _handle_create_folder(ctx):
        factory = _get_factory()
        factory.context = ctx
        return _handle_dialog_response(ctx, factory.get_lists_handler().create_folder(ctx))
    
    router.register_handler('create_list_execute', _handle_create_list)
    router.register_handler('create_folder_execute', _handle_create_folder)

    # Register list and folder view handlers
    router.register_handler('show_list', lambda ctx: _get_factory().get_lists_handler().view_list(ctx, ctx.get_param('list_id')))
    router.register_handler('show_folder', lambda ctx: _get_factory().get_lists_handler().show_folder(ctx, ctx.get_param('folder_id')))
    
    # Register quick add context handler
    def _handle_quick_add_context(ctx):
        factory = _get_factory()
        factory.context = ctx
        return factory.get_lists_handler().quick_add_context(ctx)
    
    router.register_handler('quick_add_context', _handle_quick_add_context)

    # Register parameter-based handlers with proper context setting
    def _handle_delete_list(ctx):
        factory = _get_factory()
        factory.context = ctx
        return _handle_dialog_response(ctx, factory.get_lists_handler().delete_list(ctx, ctx.get_param('list_id')))
    
    def _handle_rename_list(ctx):
        factory = _get_factory()
        factory.context = ctx
        return _handle_dialog_response(ctx, factory.get_lists_handler().rename_list(ctx, ctx.get_param('list_id')))
    
    def _handle_remove_from_list_handler(ctx):
        factory = _get_factory()
        factory.context = ctx
        return _handle_dialog_response(ctx, factory.get_lists_handler().remove_from_list(ctx, ctx.get_param('list_id'), ctx.get_param('item_id')))
    
    def _handle_rename_folder(ctx):
        factory = _get_factory()
        factory.context = ctx
        return _handle_dialog_response(ctx, factory.get_lists_handler().rename_folder(ctx, ctx.get_param('folder_id')))
    
    def _handle_delete_folder(ctx):
        factory = _get_factory()
        factory.context = ctx
        return _handle_dialog_response(ctx, factory.get_lists_handler().delete_folder(ctx, ctx.get_param('folder_id')))

    router.register_handler('delete_list', _handle_delete_list)
    router.register_handler('rename_list', _handle_rename_list)
    router.register_handler('remove_from_list', _handle_remove_from_list_handler)
    router.register_handler('rename_folder', _handle_rename_folder)
    router.register_handler('delete_folder', _handle_delete_folder)

    # Register FavoritesHandler methods
    router.register_handler('scan_favorites_execute', lambda ctx: _get_factory().get_favorites_handler().handle_scan_favorites(ctx))
    router.register_handler('save_favorites_as', lambda ctx: _get_factory().get_favorites_handler().handle_save_favorites_as(ctx))
    router.register_handler('add_favorite_to_list', lambda ctx: _handle_dialog_response(ctx, _get_factory().get_favorites_handler().add_favorite_to_list(ctx, ctx.get_param('imdb_id'))))

    # Register remaining handlers (these don't use handlers so no lazy loading needed)
    router.register_handlers({
        'authorize': lambda ctx: handle_authorize(),
        'signout': lambda ctx: handle_signout(),
        'on_select': lambda ctx: handle_on_select(ctx.params, ctx.addon_handle),
        'import_shortlist': lambda ctx: handle_shortlist_import(),
        'manual_backup': lambda ctx: _handle_manual_backup(ctx),
        'restore_backup': lambda ctx: _handle_restore_backup(ctx),
        'noop': lambda ctx: handle_noop(),
        'settings': lambda ctx: handle_settings(),
        'manual_library_sync': lambda ctx: _handle_manual_library_sync(ctx),
    })


def _handle_dialog_response(context: 'PluginContext', response):
    """Handle DialogResponse objects from handler methods"""
    from lib.ui.response_types import DialogResponse
    from lib.ui.response_handler import get_response_handler

    if isinstance(response, DialogResponse):
        response_handler = get_response_handler()
        return response_handler.handle_dialog_response(response, context)

    return response


def _handle_remove_from_list(context: 'PluginContext', lists_handler):
    """Handle remove_from_list with fallback logic"""
    list_id = context.get_param('list_id')
    item_id = context.get_param('item_id')
    
    if item_id:
        # Direct removal using item_id
        response = lists_handler.remove_from_list(context, list_id, item_id)
    else:
        # Fallback: find item by library identifiers
        dbtype = context.get_param('dbtype')
        dbid = context.get_param('dbid')
        title = context.get_param('title', '')
        
        if dbtype and dbid:
            # Try to find the media_item in the list by matching library identifiers
            try:
                query_manager = context.query_manager
                if query_manager:
                    list_items = query_manager.get_list_items(list_id)
                else:
                    list_items = []
                
                # Find matching item
                matching_item = None
                for item in list_items:
                    if (item.get('kodi_id') == int(dbid) and 
                        item.get('media_type') == dbtype):
                        matching_item = item
                        break
                
                if matching_item and 'id' in matching_item:
                    response = lists_handler.remove_from_list(context, list_id, str(matching_item['id']))
                else:
                    from lib.ui.response_types import DialogResponse
                    response = DialogResponse(
                        success=False,
                        message="Could not find item in list"
                    )
            except Exception as e:
                log_error(f"Error finding item for removal: {e}")
                from lib.ui.response_types import DialogResponse
                response = DialogResponse(
                    success=False,
                    message="Error finding item"
                )
        else:
            from lib.ui.response_types import DialogResponse
            response = DialogResponse(
                success=False,
                message="Invalid remove request"
            )
    
    return _handle_dialog_response(context, response)


def _handle_directory_response(context: 'PluginContext', response):
    """Handle DirectoryResponse objects from handler methods"""
    from lib.ui.response_types import DirectoryResponse
    from lib.ui.response_handler import get_response_handler

    if isinstance(response, DirectoryResponse):
        response_handler = get_response_handler()
        return response_handler.handle_directory_response(response, context)

    return response


if __name__ == '__main__':
    main()