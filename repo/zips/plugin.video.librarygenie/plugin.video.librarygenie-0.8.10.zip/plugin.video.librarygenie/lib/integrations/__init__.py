#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LibraryGenie - Integrations Package
Future home for external service connectors
"""

# Placeholder for future integration modules:
# - imdb_service.py
# - tmdb_service.py
# - external_search.py
# - sync_service.py
