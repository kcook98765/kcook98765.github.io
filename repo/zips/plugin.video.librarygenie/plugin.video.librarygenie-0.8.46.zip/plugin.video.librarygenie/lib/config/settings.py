#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LibraryGenie - Settings Manager
Handles addon settings and preferences
"""

from __future__ import annotations

import xbmcaddon
from typing import Any, Dict, Optional, Union

from lib.config.config_manager import get_config
from lib.utils.kodi_log import get_kodi_logger
from lib.ui.localization import L

class SettingsManager:
    """Manages all addon settings with proper type conversion and validation"""

    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.logger = get_kodi_logger('lib.config.settings')

    # General Settings

    def get_confirm_destructive(self) -> bool:
        """Get confirmation for destructive actions setting"""
        config = get_config()
        return config.get_bool('confirm_destructive_actions', True)


    # Library Settings


    def get_sync_movies(self) -> bool:
        """Get sync movies during library scan setting"""
        config = get_config()
        return config.get_bool('sync_movies', True)

    def set_sync_movies(self, enabled: bool) -> None:
        """Set sync movies during library scan setting"""
        config = get_config()
        config.set('sync_movies', enabled)

    def get_sync_tv_episodes(self) -> bool:
        """Get sync TV episodes during library scan setting"""
        config = get_config()
        return config.get_bool('sync_tv_episodes', False)

    def set_sync_tv_episodes(self, enabled: bool) -> None:
        """Set sync TV episodes during library scan setting"""
        config = get_config()
        config.set('sync_tv_episodes', enabled)

    def get_first_run_completed(self) -> bool:
        """Get whether first run setup has been completed"""
        config = get_config()
        return config.get_bool('first_run_completed', False)

    def set_first_run_completed(self, completed: bool) -> None:
        """Set whether first run setup has been completed"""
        config = get_config()
        config.set('first_run_completed', completed)


    # Lists Settings
    def get_default_list_id(self) -> Optional[str]:
        """Get default list ID for quick-add"""
        config = get_config()
        value = config.get('default_list_id', "")
        return value if value else None

    def set_default_list_id(self, list_id: str) -> None:
        """Set default list ID for quick-add"""
        config = get_config()
        config.set('default_list_id', str(list_id) if list_id else "")

    def get_enable_quick_add(self) -> bool:
        """Get enable quick-add setting"""
        config = get_config()
        return config.get_bool('quick_add_enabled', False)

    def get_show_missing_indicators(self) -> bool:
        """Get show missing movie indicators setting"""
        config = get_config()
        return config.get_bool('show_missing_indicators', True)

    # Background Service Settings
    def get_enable_background_service(self) -> bool:
        """Get enable background service setting"""
        config = get_config()
        return config.get_bool('enable_background_service', True)

    def get_background_interval(self) -> int:
        """Get background service interval in minutes"""
        config = get_config()
        value = config.get_int('background_interval', 5)
        return max(5, min(720, value))

    def get_library_sync_interval(self) -> int:
        """Get library sync interval in minutes. Returns 0 if disabled."""
        config = get_config()
        interval_setting = config.get_int('library_sync_interval', 0)
        
        # Map setting values to minutes
        interval_map = {
            0: 0,       # Disabled
            1: 5,       # 5 Minutes  
            2: 60,      # Hourly
            3: 1440     # Daily (24 hours * 60 minutes)
        }
        
        return interval_map.get(interval_setting, 0)

    def set_library_sync_interval(self, interval: int) -> None:
        """Set library sync interval setting (0=disabled, 1=5min, 2=hourly, 3=daily)"""
        config = get_config()
        config.set('library_sync_interval', interval)

    # Favorites Settings
    def get_enable_favorites_integration(self) -> bool:
        """Get enable favorites integration setting"""
        config = get_config()
        return config.get_bool('favorites_integration_enabled', False)

    def get_favorites_scan_interval(self) -> int:
        """Get favorites scan interval in minutes"""
        config = get_config()
        value = config.get_int('favorites_scan_interval', 30)
        return max(5, min(1440, value))

    def get_show_unmapped_favorites(self) -> bool:
        """Get show unmapped favorites setting"""
        config = get_config()
        return config.get_bool('show_unmapped_favorites', False)

    def get_enable_batch_processing(self) -> bool:
        """Get enable batch processing for large favorites files"""
        config = get_config()
        return config.get_bool('enable_batch_processing', True)



    # Search Settings
    def get_search_page_size(self) -> int:
        """Get search results page size"""
        config = get_config()
        value = config.get_int('search_page_size', 200)
        return max(50, min(500, value))

    # Pagination Settings
    def get_list_pagination_mode(self) -> str:
        """Get list pagination mode ('auto' or 'manual')"""
        config = get_config()
        # Setting is stored as integer: 0=auto, 1=manual
        value = config.get_int('list_pagination_mode', 0)
        return 'manual' if value == 1 else 'auto'
        
    def get_list_manual_page_size(self) -> int:
        """Get manual page size (clamped to 100-5000 to match settings.xml constraints)"""
        config = get_config()
        # Only read the setting if we're in manual mode to avoid Kodi warnings
        # when the setting is disabled by dependency rules
        pagination_mode = self.get_list_pagination_mode()
        if pagination_mode != 'manual':
            # Return default when in auto mode (setting is disabled)
            return 100
        value = config.get_int('list_manual_page_size', 100)
        return max(100, min(5000, value))

    # Advanced Settings
    def get_jsonrpc_page_size(self) -> int:
        """Get JSON-RPC page size"""
        config = get_config()
        value = config.get_int('jsonrpc_page_size', 200)
        return max(50, min(500, value))

    def get_jsonrpc_timeout(self) -> int:
        """Get JSON-RPC timeout in seconds"""
        config = get_config()
        value = config.get_int('jsonrpc_timeout', 10)
        return max(5, min(60, value))

    def get_database_batch_size(self) -> int:
        """Get database batch size"""
        config = get_config()
        value = config.get_int('database_batch_size', 200)
        return max(100, min(1000, value))

    def get_database_busy_timeout(self) -> int:
        """Get database busy timeout in milliseconds"""
        config = get_config()
        value = config.get_int('database_busy_timeout', 3000)
        return max(1000, min(30000, value))

    # Remote Service Settings
    def get_remote_server_url(self) -> Optional[str]:
        """Get remote server URL"""
        config = get_config()
        value = config.get('remote_server_url', "")
        return value.strip() if value else None

    def get_device_name(self) -> str:
        """Get device name for authentication"""
        config = get_config()
        value = config.get('device_name', "Kodi")
        return value if value else L(30412)  # "Device name"

    def get_auth_polling_interval(self) -> int:
        """Get authentication polling interval in seconds (hard-coded to 5 seconds)"""
        return 5

    def get_enable_auto_token_refresh(self) -> bool:
        """Get enable automatic token refresh setting"""
        config = get_config()
        return config.get_bool('enable_auto_token_refresh', True)


    def get_debug_first_playable(self) -> bool:
        """Get whether to enable first playable listitem debugging"""
        config = get_config()
        return config.get_bool('debug_first_playable', False)

    def set_debug_first_playable(self, enabled: bool) -> None:
        """Set whether to enable first playable listitem debugging"""
        config = get_config()
        config.set('debug_first_playable', enabled)

    def get_enable_background_token_refresh(self) -> bool:
        """Get enable automatic token refresh in background service setting"""
        config = get_config()
        return config.get_bool('enable_background_token_refresh', True)

    # AI Search Server Settings

    def get_ai_search_api_key(self) -> Optional[str]:
        """Get AI search API key"""
        config = get_config()
        value = config.get('ai_search_api_key', "")
        return value.strip() if value else None

    def set_ai_search_api_key(self, api_key: str) -> None:
        """Set AI search API key"""
        config = get_config()
        config.set('ai_search_api_key', api_key if api_key else "")

    def get_ai_search_activated(self) -> bool:
        """Get AI search activated status"""
        config = get_config()
        return config.get_bool('ai_search_activated', False)


    def set_ai_search_activated(self, activated: bool) -> None:
        """Set AI search activated status"""
        config = get_config()
        config.set('ai_search_activated', activated)


    def get_ai_search_sync_interval(self) -> int:
        """Get AI search sync interval in seconds"""
        config = get_config()
        selector_value = config.get_int('ai_search_sync_interval', 1)
        # Map selector values to seconds: 0=1hr, 1=12hr, 2=24hr
        interval_map = {
            0: 3600,    # 1 Hour
            1: 43200,   # 12 Hours  
            2: 86400    # 24 Hours
        }
        return interval_map.get(selector_value, 43200)  # Default to 12 hours

    # Backup Settings
    def get_enable_automatic_backups(self) -> bool:
        """Get enable automatic backups setting"""
        config = get_config()
        return config.get_bool('enable_automatic_backups', False)

    def get_backup_interval(self) -> str:
        """Get backup interval setting"""
        config = get_config()
        return config.get('backup_interval', 'weekly')

    def get_backup_storage_location(self) -> str:
        """Get backup storage location with safe fallbacks"""
        config = get_config()
        # Read the backup_storage_location setting directly
        custom_path = config.get('backup_storage_location', "")
        if custom_path and custom_path.strip():
            return custom_path.strip()

        # Default to addon data directory
        return "special://userdata/addon_data/plugin.video.librarygenie/backups/"

    def get_backup_storage_type(self) -> str:
        """Get backup storage type with safe fallback"""
        config = get_config()
        return config.get('backup_storage_type', 'local')

    def get_backup_enabled(self) -> bool:
        """Get backup enabled setting with safe fallback"""
        config = get_config()
        return config.get_bool('backup_enabled', False)

    def get_backup_retention_count(self) -> int:
        """Get backup retention count with safe fallback"""
        config = get_config()
        value = config.get_int('backup_retention_count', 5)
        return max(1, min(50, value))

    def get_backup_retention_policy(self) -> str:
        """Get backup retention policy"""
        config = get_config()
        return config.get('backup_retention_policy', 'count')

    # ShortList Integration Settings
    def get_import_from_shortlist(self) -> bool:
        """Get import from ShortList addon setting"""
        config = get_config()
        return config.get_bool('import_from_shortlist', False)

    def get_clear_before_import(self) -> bool:
        """Get clear list before importing setting"""
        config = get_config()
        return config.get_bool('clear_before_import', False)

    # Settings Helper Methods
    def set_setting(self, setting_id: str, value: Union[str, bool, int]) -> None:
        """Set a setting value with proper type conversion"""
        try:
            if isinstance(value, bool):
                self.addon.setSettingBool(setting_id, value)
            elif isinstance(value, int):
                self.addon.setSettingInt(setting_id, value)
            else:
                self.addon.setSetting(setting_id, str(value))
            self.logger.debug("Setting %s set to %s", setting_id, value)
        except Exception as e:
            self.logger.error("Failed to set setting %s: %s", setting_id, e)

    def reset_to_defaults(self) -> None:
        """Reset all settings to their default values"""
        try:
            # This would require iterating through all settings and resetting them
            # For now, we'll log the action
            self.logger.info(L(30131))  # "Setting restored to default"
        except Exception as e:
            self.logger.error("Failed to reset settings: %s", e)

    def validate_settings(self) -> bool:
        """Validate all settings and return True if valid"""
        try:
            # Perform basic validation checks
            if self.get_background_interval() < 5:
                self.logger.warning("Background interval too low, using minimum")
                return False

            if self.get_jsonrpc_page_size() > 500:
                self.logger.warning("JSON-RPC page size too high, using maximum")
                return False

            self.logger.info(L(30132))  # "Configuration validated"
            return True
        except Exception as e:
            self.logger.error("%s: %s", L(30133), e)  # "Configuration validation failed"
            return False

    def get_validation_status_message(self, is_valid: bool) -> str:
        """Get localized validation status message"""
        return L(30132) if is_valid else L(30133)  # "Configuration validated" or "Configuration validation failed"

    def get_setting_save_message(self, success: bool) -> str:
        """Get localized setting save message"""
        return L(30129) if success else L(30130)  # "Setting saved successfully" or "Failed to save setting"

    def get_backup_preferences(self) -> Dict[str, Any]:
        """Get backup-related preferences with defaults"""
        try:
            config = get_config()
            return {
                'enabled': self.get_backup_enabled(),
                'schedule_interval': self.get_backup_interval(),
                'retention_days': self.get_backup_retention_count(),
                'storage_path': self.get_backup_storage_location(),
                'storage_type': self.get_backup_storage_type(),
                'include_settings': config.get_bool('backup_include_settings', True),
                'include_non_library': config.get_bool('backup_include_non_library', False)
            }
        except Exception as e:
            self.logger.warning("Error reading backup preferences: %s", e)
            return {
                'enabled': False,
                'schedule_interval': 'weekly',
                'retention_days': 5,
                'storage_path': "special://userdata/addon_data/plugin.video.librarygenie/backups/",
                'storage_type': 'local',
                'include_settings': True,
                'include_non_library': False
            }

    def get_phase12_remote_settings(self) -> Dict[str, Any]:
        """Get remote service settings for Phase 1.2 integration"""
        config = get_config()
        return {
            'enabled': config.get_bool('remote_enabled', False),
            'server_url': self.get_remote_server_url(),
            'timeout': config.get_int('remote_timeout', 30),
            'max_retries': config.get_int('remote_max_retries', 3),
            'fallback_to_local': config.get_bool('remote_fallback_to_local', True),
            'cache_duration': config.get_int('remote_cache_duration', 300)
        }

    # Folder Cache Settings
    def get_folder_cache_enabled(self) -> bool:
        """Get folder cache enabled setting"""
        config = get_config()
        return config.get_bool('folder_cache_enabled', True)

    def set_folder_cache_enabled(self, enabled: bool) -> None:
        """Set folder cache enabled setting"""
        config = get_config()
        config.set('folder_cache_enabled', enabled)

    def get_folder_cache_fresh_ttl(self) -> int:
        """Get folder cache fresh TTL in hours"""
        config = get_config()
        return config.get_int('folder_cache_fresh_ttl', 12)

    def set_folder_cache_fresh_ttl(self, hours: int) -> None:
        """Set folder cache fresh TTL in hours"""
        config = get_config()
        config.set('folder_cache_fresh_ttl', max(1, hours))  # Minimum 1 hour

    def get_folder_cache_hard_expiry(self) -> int:
        """Get folder cache hard expiry in days"""
        config = get_config()
        return config.get_int('folder_cache_hard_expiry', 30)

    def set_folder_cache_hard_expiry(self, days: int) -> None:
        """Set folder cache hard expiry in days"""
        config = get_config()
        config.set('folder_cache_hard_expiry', max(1, days))  # Minimum 1 day

    def get_folder_cache_prewarm_enabled(self) -> bool:
        """Get folder cache pre-warming enabled setting"""
        config = get_config()
        return config.get_bool('folder_cache_prewarm_enabled', True)

    def set_folder_cache_prewarm_enabled(self, enabled: bool) -> None:
        """Set folder cache pre-warming enabled setting"""
        config = get_config()
        config.set('folder_cache_prewarm_enabled', enabled)

    def get_folder_cache_prewarm_max_folders(self) -> int:
        """Get maximum folders to pre-warm"""
        config = get_config()
        return config.get_int('folder_cache_prewarm_max_folders', 10)

    def set_folder_cache_prewarm_max_folders(self, max_folders: int) -> None:
        """Set maximum folders to pre-warm"""
        config = get_config()
        config.set('folder_cache_prewarm_max_folders', max(1, max_folders))  # Minimum 1 folder

    def get_folder_cache_debug_logging(self) -> bool:
        """Get folder cache debug logging enabled setting"""
        config = get_config()
        return config.get_bool('folder_cache_debug_logging', False)

    def set_folder_cache_debug_logging(self, enabled: bool) -> None:
        """Set folder cache debug logging enabled setting"""
        config = get_config()
        config.set('folder_cache_debug_logging', enabled)

    def get_folder_cache_preferences(self) -> Dict[str, Any]:
        """Get folder cache-related preferences with defaults"""
        try:
            return {
                'enabled': self.get_folder_cache_enabled(),
                'fresh_ttl_hours': self.get_folder_cache_fresh_ttl(),
                'hard_expiry_days': self.get_folder_cache_hard_expiry(),
                'prewarm_enabled': self.get_folder_cache_prewarm_enabled(),
                'prewarm_max_folders': self.get_folder_cache_prewarm_max_folders(),
                'debug_logging': self.get_folder_cache_debug_logging()
            }
        except Exception as e:
            self.logger.warning("Error reading folder cache preferences: %s", e)
            return {
                'enabled': True,
                'fresh_ttl_hours': 12,
                'hard_expiry_days': 30,
                'prewarm_enabled': True,
                'prewarm_max_folders': 10,
                'debug_logging': False
            }


# Module-level convenience functions
def get_phase12_remote_settings() -> Dict[str, Any]:
    """Module-level function to get remote service settings for Phase 1.2 integration"""
    settings_manager = SettingsManager()
    return settings_manager.get_phase12_remote_settings()