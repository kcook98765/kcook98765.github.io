#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LibraryGenie - Menu Builder
Centralized menu construction for consistent UI
"""

import xbmc
import xbmcgui
from lib.ui.localization import L